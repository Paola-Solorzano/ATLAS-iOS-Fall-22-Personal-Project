/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

let story = Story(pages: [
    StoryPage( // 0 - Homepage
        
        """
         
         
        Welcome to Quick Cooks, the app that makes cooking quick and easy!
        
        To get started, choose what cuisine you would like to see recipes for.
        
        """,
        choices: [
            Choice(text: "American", destination: 1),
            Choice(text: "Mexican", destination: 2),
            Choice(text: "Italian", destination: 3),
            Choice(text: "Chinese", destination: 4),
            Choice(text: "Lebanese", destination: 5),
        ]
    ),
    StoryPage( // 1 - American
        """
        Yummy!
        What kind of American recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 6),
            Choice(text: "Entrees / Main Dishes", destination: 7),
            Choice(text: "Desserts", destination: 8),
            Choice(text: "Drinks", destination: 9),
        ]
             ),
    StoryPage( // 2 - Mexican
        """
        Fantastic choice!
        What kind of Mexican recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 10),
            Choice(text: "Entrees / Main Dishes", destination: 11),
            Choice(text: "Desserts", destination: 12),
            Choice(text: "Drinks", destination: 13),
        ]
    ),
    StoryPage( // 3 - Italian
        """
        Great choice!
        What kind of Italian recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 14),
            Choice(text: "Entrees / Main Dishes", destination: 15),
            Choice(text: "Desserts", destination: 16),
            Choice(text: "Drinks", destination: 17),
        ]
    ),
    StoryPage( // 4 - Chinese
        """
        Good choice!
        What kind of Chinese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 18),
            Choice(text: "Entrees / Main Dishes", destination: 19),
            Choice(text: "Desserts", destination: 20),
            Choice(text: "Drinks", destination: 21),
        ]
    ),
    StoryPage( // 5 - Lebanese
        """
        Delicious!
        What kind of Lebanese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 22),
            Choice(text: "Entrees / Main Dishes", destination: 23),
            Choice(text: "Desserts", destination: 24),
            Choice(text: "Drinks", destination: 25),
        ]
    ),
    StoryPage( // 6 - appetizers American
        """
        Here are some recipes for American appetizers!
        
        1. Hogs in a Blanket
        2. Buffalo Chicken Wings
        3. Mozzarella Sticks
        4. Crispy Loaded Potato Skins
        5. Pepporoni Pizza Monkey Bread
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 7 - entree American
        """
        Here are some recipes for American entrees and main dishes!
        """,
        choices: [
//            Choice(text: "Home", destination: 0),
//            Choice(text: "Keep working away, your cake will be great even without the specialty item.", destination: 20),
        ]
    ),
    StoryPage( // 8 - desserts American
        """
        Here are some recipes for American desserts!
        """,

        choices: [
//            Choice(text: "Pipe the decorations onto parchment paper. You can transfer them at the last minute.", destination: 17),
//            Choice(text: "Start decorating, you don’t have a minute to waste.", destination: 18),
        ]
    ),
    StoryPage( // 9 - drinks American
        """
        Here are some recipes for American drinks!
        """,
        choices: [
//            Choice(text: "Marzipan, and lots of it!", destination: 19),
//            Choice(text: "Several bags of different color icing.", destination: 20),
        ]
    ),
    StoryPage( // 10 - appetizers Mexican
        """
        Here are some recipes for Mexican appetizers!
        """,
        choices: []
    ),
    StoryPage( // 11 - entree Mexican
        """
        Here are some recipes for Mexican entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 12 - desserts Mexican
        """
        Here are some recipes for Mexican desserts!
        """,
        choices: []
    ),
    StoryPage( // 13 - drinks Mexican
        """
        Here are some recipes for Mexican drinks!
        """,
        choices: []
    ),
    StoryPage( // 14 - appetizers Italian
        """
        Here are some recipes for Italian appetizers!
        """,

        choices: []
    ),
    StoryPage( // 15 - entrees Italian
        """
        Here are some recipes for Italian entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 16 - desserts Italian
        """
        Here are some recipes for Italian desserts
        """,
        choices: []
    ),
    StoryPage( // 17 - drinks Italian
        """
        Here are some recipes for Italian drinks!
        """,
        choices: []
    ),
    StoryPage( // 18 - appetizers Chinese
        """
        Here are some recipes for Chinese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 19 - entrees Chinese
        """
        Here are some recipes for Chinese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 20 - desserts Chinese
        """
        Here are some recipes for Chinese desserts!
        """,
        choices: []
    ),
    StoryPage( // 21 - drinks Chinese
        """
        Here are some recipes for Chinese drinks!
        """,
        choices: []
    ),
    StoryPage( // 22 - appetizers Lebanese
        """
        Here are some recipes for Lebanese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 23 - entrees Lebanese
        """
        Here are some recipes for Lebanese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 24 - desserts Lebanese
        """
        Here are some recipes for Lebanese desserts!
        """,
        choices: []
    ),
    StoryPage( // 25 - drinks Lebanese
        """
        Here are some recipes for Lebanese drinks!
        """,
        choices: []
    ),
])
