/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

let story = Story(pages: [
    StoryPage( // 0 - Homepage
        
        """
         
         
            Welcome to Quick Cooks, the app that makes cooking quick and easy!
        
            To get started, choose what cuisine you would like to see recipes for.
        
        """,
        choices: [
            Choice(text: "American", destination: 1),
            Choice(text: "Mexican", destination: 2),
            Choice(text: "Italian", destination: 3),
            Choice(text: "Chinese", destination: 4),
            Choice(text: "Lebanese", destination: 5),
        ]
    ),
    StoryPage( // 1 - American
        """
        
        Yummy!
        
            What kind of American recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 6),
            Choice(text: "Entrees / Main Dishes", destination: 7),
            Choice(text: "Desserts", destination: 8),
            Choice(text: "Drinks", destination: 9),
        ]
             ),
    StoryPage( // 2 - Mexican
        """
        Fantastic choice!
        
            What kind of Mexican recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 10),
            Choice(text: "Entrees / Main Dishes", destination: 11),
            Choice(text: "Desserts", destination: 12),
            Choice(text: "Drinks", destination: 13),
        ]
    ),
    StoryPage( // 3 - Italian
        """
        Great choice!
        
            What kind of Italian recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 14),
            Choice(text: "Entrees / Main Dishes", destination: 15),
            Choice(text: "Desserts", destination: 16),
            Choice(text: "Drinks", destination: 17),
        ]
    ),
    StoryPage( // 4 - Chinese
        """
        Good choice!
        
            What kind of Chinese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 18),
            Choice(text: "Entrees / Main Dishes", destination: 19),
            Choice(text: "Desserts", destination: 20),
            Choice(text: "Drinks", destination: 21),
        ]
    ),
    StoryPage( // 5 - Lebanese
        """
        Delicious!
        
            What kind of Lebanese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 22),
            Choice(text: "Entrees / Main Dishes", destination: 23),
            Choice(text: "Desserts", destination: 24),
            Choice(text: "Drinks", destination: 25),
        ]
    ),
    StoryPage( // 6 - appetizers American
        """
        
        
        
        
        
        Here are some recipes for American appetizers!
        """,
        choices: [
            Choice(text: "Hogs in a Blanket", destination: 26),
            Choice(text: "Buffalo Chicken Wings", destination: 27),
            Choice(text: "Mozzarella Sticks", destination: 28),
        ]
    ),
    StoryPage( // 7 - entree American
        """
        Here are some recipes for American entrees and main dishes!
        """,
        choices: [
//            Choice(text: "Home", destination: 0),
//            Choice(text: "Keep working away, your cake will be great even without the specialty item.", destination: 20),
        ]
    ),
    StoryPage( // 8 - desserts American
        """
        Here are some recipes for American desserts!
        """,

        choices: [
//            Choice(text: "Pipe the decorations onto parchment paper. You can transfer them at the last minute.", destination: 17),
//            Choice(text: "Start decorating, you don’t have a minute to waste.", destination: 18),
        ]
    ),
    StoryPage( // 9 - drinks American
        """
        Here are some recipes for American drinks!
        """,
        choices: [
//            Choice(text: "Marzipan, and lots of it!", destination: 19),
//            Choice(text: "Several bags of different color icing.", destination: 20),
        ]
    ),
    StoryPage( // 10 - appetizers Mexican
        """
        Here are some recipes for Mexican appetizers!
        """,
        choices: []
    ),
    StoryPage( // 11 - entree Mexican
        """
        Here are some recipes for Mexican entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 12 - desserts Mexican
        """
        Here are some recipes for Mexican desserts!
        """,
        choices: []
    ),
    StoryPage( // 13 - drinks Mexican
        """
        Here are some recipes for Mexican drinks!
        """,
        choices: []
    ),
    StoryPage( // 14 - appetizers Italian
        """
        Here are some recipes for Italian appetizers!
        """,

        choices: []
    ),
    StoryPage( // 15 - entrees Italian
        """
        Here are some recipes for Italian entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 16 - desserts Italian
        """
        Here are some recipes for Italian desserts
        """,
        choices: []
    ),
    StoryPage( // 17 - drinks Italian
        """
        Here are some recipes for Italian drinks!
        """,
        choices: []
    ),
    StoryPage( // 18 - appetizers Chinese
        """
        Here are some recipes for Chinese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 19 - entrees Chinese
        """
        Here are some recipes for Chinese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 20 - desserts Chinese
        """
        Here are some recipes for Chinese desserts!
        """,
        choices: []
    ),
    StoryPage( // 21 - drinks Chinese
        """
        Here are some recipes for Chinese drinks!
        """,
        choices: []
    ),
    StoryPage( // 22 - appetizers Lebanese
        """
        Here are some recipes for Lebanese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 23 - entrees Lebanese
        """
        Here are some recipes for Lebanese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 24 - desserts Lebanese
        """
        Here are some recipes for Lebanese desserts!
        """,
        choices: []
    ),
    StoryPage( // 25 - drinks Lebanese
        """
        Here are some recipes for Lebanese drinks!
        """,
        choices: []
    ),
    StoryPage( // 26 - appetizers American hogs in blanket
        """
        
        
        Hogs in a Blanket
        
        ----------------------------------------------
        
            -- Ingredients --
                * 7 ounces all-butter puff pastry
                  (thawed and cut into four 5-inch squares)
                * 1 egg yolk mixed with tablespoon of water (large)
                * 4 andouille sausages (3 ounces
                  each)
                * ¼ cup Major Grey’s chutney
                * 2 tablespoons whole-grain mustard
            
                --------------  --------------
        
            -- Directions --
                1. Preheat the oven to 375° and position   a rack in the center. Arrange the puff pastry squares on a work surface and brush the top edges with the egg wash. Place the sausages on the bottom edges and roll up the pastry, pressing the edges to seal. Freeze the logs for 10 minutes, or until firm.
        
                2. Cut the logs into 1/2-inch slices and place them cut side up in 3 mini muffin pans. Bake for 25 minutes, until golden and sizzling. Turn out onto a paper towel-lined rack to cool.
        
                3. Meanwhile, in a mini food processor, pulse the chutney and mustard just until the chutney is chopped. Spoon a dollop of the chutney mustard on each slice and serve.
        
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 27 - appetizers American buffalo wings
        """
        
        Buffalo Chicken Wings
        
        ----------------------------------------------
        
            -- Wing Ingredients --
        
                * 3 lb chicken wings, wings and drummettes split, wingtips removed
                * 1 Tbsp baking powder, (use aluminum free)
                * 1 tsp fine sea salt
                * 2 tsp garlic powder
        
            -- Sauce Ingredients --
        
                * 1/4 cup unsalted butter, melted
                * 1/4 cup Franks Original Red Hot Sauce
                * 1 tbsp granulated sugar, or brown sugar

        
            -- Directions --
        
                1. Thoroughly pat dry the chicken with a paper towel. Preheat the oven to 450˚F. Line a rimmed baking sheet with foil and place a wire rack over the pan.
        
                2. Combine the baking powder, salt and garlic powder in a bowl, sprinkle over the chicken and toss to combine. Arrange chicken on the prepared wire rack.
        
                3. Bake the chicken for 25 minutes, flip it over and bake for another 25 minutes or until crisp and cooked through.
        
                4. In a medium-size bowl combine sauce  ingredients. Remove chicken from the baking sheet to a bowl. Drizzle the sauce over the chicken. Toss to coat the chicken in the sauce. Serve with your favorite dipping sauce.

        
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 28 - appetizers American mozzarella sticks
        """
        
        Mozzarella Sticks
        ----------------------------------------------
        
            -- Ingredients --
                * 1 pound mozzarella
                * 3 eggs
                * 3 Tablespoons milk
                * 1 ½ cups Italian breadcrumbs
                * ½ cup freshly grated parmesan cheese
                * ½ teaspoon salt
                * Vegetable oil for frying
                * Marinara sauce for dipping
        
            -- Directions --
                1. Slice the brick of mozzarella cheese into 16 sticks that are each about 3 ½" long.
        
                2. In a shallow bowl, whisk together the eggs and milk. In a separate shallow dish like a pie plate, stir together the breadcrumbs, Parmesan cheese, and salt.
        
                3. Working one at a time, dip each mozzarella stick into the egg wash, let the excess drip off, then roll in the breadcrumbs. Repeat the process for each mozzarella stick for a double coating of bread crumbs by dipping again in the egg wash and breadcrumbs before transferring to a sheet pan. Continue until all of the cheese is coated and the breadcrumbs have been used up.
        
                4. Transfer the mozzarella sticks to the freezer and freeze for at least 1 hour.
        
                5. Fill a large skillet at least 1"-2" deep with vegetable oil, or use a deep fryer if you have one. Heat the oil to between 350 and 365 degrees F over medium-high heat. The temperature will drop when the frozen mozzarella sticks are added, so use a thermometer to monitor the oil temp and keep it in range.
        
                6. Working in batches, fry 5-6 mozzarella sticks at a time for 1-2 minutes, carefully turning with tongs halfway through, until crispy and golden brown on the outside. Remove the fried mozzarella sticks to a plate lined with a paper towel to soak up any excess oil.
        
                7. Continue to fry the remaining mozzarella sticks, then serve hot with marinara sauce for dipping.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
])
