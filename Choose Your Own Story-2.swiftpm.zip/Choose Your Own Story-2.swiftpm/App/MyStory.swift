 /*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

let story = Story(pages: [
    StoryPage( // 0 - Homepage
        
        """
         
         
            Welcome to Quick Cooks, the app that makes cooking quick and easy!
        
            To get started, choose what cuisine you would like to see recipes for.
        
        """,
        choices: [
            Choice(text: "American", destination: 1),
            Choice(text: "Mexican", destination: 2),
            Choice(text: "Italian", destination: 3),
//            Choice(text: "Chinese", destination: 4),
//            Choice(text: "Lebanese", destination: 5),
        ]
    ),
    StoryPage( // 1 - American
        """
        
        Yummy!
        
            What kind of American recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 6),
            Choice(text: "Entrees / Main Dishes", destination: 7),
            Choice(text: "Desserts", destination: 8),
            Choice(text: "Drinks", destination: 9),
        ]
             ),
    StoryPage( // 2 - Mexican
        """
        
        
        Fantastic choice!
        
            What kind of Mexican recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 10),
            Choice(text: "Entrees / Main Dishes", destination: 11),
            Choice(text: "Desserts", destination: 12),
            Choice(text: "Drinks", destination: 13),
        ]
    ),
    StoryPage( // 3 - Italian
        """
        
        
        Great choice!
        
            What kind of Italian recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 14),
            Choice(text: "Entrees / Main Dishes", destination: 15),
            Choice(text: "Desserts", destination: 16),
            Choice(text: "Drinks", destination: 17),
        ]
    ),
    StoryPage( // 4 - Chinese
        """
        Good choice!
        
            What kind of Chinese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 18),
            Choice(text: "Entrees / Main Dishes", destination: 19),
            Choice(text: "Desserts", destination: 20),
            Choice(text: "Drinks", destination: 21),
        ]
    ),
    StoryPage( // 5 - Lebanese
        """
        Delicious!
        
            What kind of Lebanese recipes would you like to see?
        """,
        choices: [
            Choice(text: "Appetizers", destination: 22),
            Choice(text: "Entrees / Main Dishes", destination: 23),
            Choice(text: "Desserts", destination: 24),
            Choice(text: "Drinks", destination: 25),
        ]
    ),
    StoryPage( // 6 - appetizers American
        """
        
        
        
        
        
        Here are some recipes for American appetizers!
        """,
        choices: [
            Choice(text: "Hogs in a Blanket", destination: 26),
            Choice(text: "Buffalo Chicken Wings", destination: 27),
            Choice(text: "Mozzarella Sticks", destination: 28),
        ]
    ),
    StoryPage( // 7 - entree American
        """
            
            Here are some recipes for American entrees and main dishes!
        """,
        choices: [
            Choice(text: "Clam Chowder", destination: 29),
            Choice(text: "Texas BBQ Brisket", destination: 30),
            Choice(text: "Pot Roast", destination: 31),
        ]
    ),
    StoryPage( // 8 - desserts American
        """
            
            Here are some recipes for American desserts!
        """,

        choices: [
            Choice(text: "Apple Pie", destination: 32),
            Choice(text: "Carrot Cake", destination: 33),
            Choice(text: "Banana Pudding", destination: 34),
        ]
    ),
    StoryPage( // 9 - drinks American
        """
        
            Here are some recipes for American drinks!
        """,
        choices: [
            Choice(text: "Bloody Mary", destination: 35),
            Choice(text: "Old-fashioned", destination: 36),
            Choice(text: "Pina Colada", destination: 37),
        ]
    ),
    StoryPage( // 10 - appetizers Mexican
        """
        
            Here are some recipes for Mexican appetizers!
        """,
        choices: [
            Choice(text: "Guacamole Dip", destination: 38),
            Choice(text: "Salsa Dip", destination: 39),
            Choice(text: "Cochinita Pibil", destination: 40)]
    ),
    StoryPage( // 11 - entree Mexican
        """
        Here are some recipes for Mexican entrees and main dishes!
        """,
        choices: [
            Choice(text: "Mole Poblano", destination: 41),
            Choice(text: "Posole", destination: 42),
            Choice(text: "Tamales", destination: 43)]
    ),
    StoryPage( // 12 - desserts Mexican
        """
        Here are some recipes for Mexican desserts!
        """,
        choices: [
            Choice(text: "Bunuelos", destination: 44),
            Choice(text: "Capirotada", destination: 45),
            Choice(text: "Pan de Muerto", destination: 46)]
    ),
    StoryPage( // 13 - drinks Mexican
        """
        Here are some recipes for Mexican drinks!
        """,
        choices: [
            Choice(text: "Arroz con Leche", destination: 47),
            Choice(text: "Agua de Horchata", destination: 48),
            Choice(text: "Agua de Jamaica", destination: 49)]
    ),
    StoryPage( // 14 - appetizers Italian
        """
        Here are some recipes for Italian appetizers!
        """,

        choices: []
    ),
    StoryPage( // 15 - entrees Italian
        """
        Here are some recipes for Italian entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 16 - desserts Italian
        """
        Here are some recipes for Italian desserts
        """,
        choices: []
    ),
    StoryPage( // 17 - drinks Italian
        """
        Here are some recipes for Italian drinks!
        """,
        choices: []
    ),
    StoryPage( // 18 - appetizers Chinese
        """
        Here are some recipes for Chinese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 19 - entrees Chinese
        """
        Here are some recipes for Chinese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 20 - desserts Chinese
        """
        Here are some recipes for Chinese desserts!
        """,
        choices: []
    ),
    StoryPage( // 21 - drinks Chinese
        """
        Here are some recipes for Chinese drinks!
        """,
        choices: []
    ),
    StoryPage( // 22 - appetizers Lebanese
        """
        Here are some recipes for Lebanese appetizers!
        """,
        choices: []
    ),
    StoryPage( // 23 - entrees Lebanese
        """
        Here are some recipes for Lebanese entrees and main dishes!
        """,
        choices: []
    ),
    StoryPage( // 24 - desserts Lebanese
        """
        Here are some recipes for Lebanese desserts!
        """,
        choices: []
    ),
    StoryPage( // 25 - drinks Lebanese
        """
        Here are some recipes for Lebanese drinks!
        """,
        choices: []
    ),
    StoryPage( // 26 - appetizers American hogs in blanket
        """
        
        
        Hogs in a Blanket
        
        ----------------------------------------------
        
            -- Ingredients --
                * 7 ounces all-butter puff pastry
                  (thawed and cut into four 5-inch squares)
                * 1 egg yolk mixed with tablespoon of water (large)
                * 4 andouille sausages (3 ounces
                  each)
                * ¼ cup Major Grey’s chutney
                * 2 tablespoons whole-grain mustard
            
                --------------  --------------
        
            -- Directions --
                1. Preheat the oven to 375° and position   a rack in the center. Arrange the puff pastry squares on a work surface and brush the top edges with the egg wash. Place the sausages on the bottom edges and roll up the pastry, pressing the edges to seal. Freeze the logs for 10 minutes, or until firm.
        
                2. Cut the logs into 1/2-inch slices and place them cut side up in 3 mini muffin pans. Bake for 25 minutes, until golden and sizzling. Turn out onto a paper towel-lined rack to cool.
        
                3. Meanwhile, in a mini food processor, pulse the chutney and mustard just until the chutney is chopped. Spoon a dollop of the chutney mustard on each slice and serve.
        
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 27 - appetizers American buffalo wings
        """
        
        🍗 Buffalo Chicken Wings 🍗
        
        ----------------------------------------------
        
            -- Wing Ingredients --
        
                * 3 lb chicken wings, wings and drummettes split, wingtips removed
                * 1 Tbsp baking powder, (use aluminum free)
                * 1 tsp fine sea salt
                * 2 tsp garlic powder
        
            -- Sauce Ingredients --
        
                * 1/4 cup unsalted butter, melted
                * 1/4 cup Franks Original Red Hot Sauce
                * 1 tbsp granulated sugar, or brown sugar

        
            -- Directions --
        
                1. Thoroughly pat dry the chicken with a paper towel. Preheat the oven to 450˚F. Line a rimmed baking sheet with foil and place a wire rack over the pan.
        
                2. Combine the baking powder, salt and garlic powder in a bowl, sprinkle over the chicken and toss to combine. Arrange chicken on the prepared wire rack.
        
                3. Bake the chicken for 25 minutes, flip it over and bake for another 25 minutes or until crisp and cooked through.
        
                4. In a medium-size bowl combine sauce  ingredients. Remove chicken from the baking sheet to a bowl. Drizzle the sauce over the chicken. Toss to coat the chicken in the sauce. Serve with your favorite dipping sauce.

        
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 28 - appetizers American mozzarella sticks
        """
        
        Mozzarella Sticks
        ----------------------------------------------
        
            -- Ingredients --
                * 1 pound mozzarella
                * 3 eggs
                * 3 Tablespoons milk
                * 1 ½ cups Italian breadcrumbs
                * ½ cup freshly grated parmesan cheese
                * ½ teaspoon salt
                * Vegetable oil for frying
                * Marinara sauce for dipping
        
            -- Directions --
                1. Slice the brick of mozzarella cheese into 16 sticks that are each about 3 ½" long.
        
                2. In a shallow bowl, whisk together the eggs and milk. In a separate shallow dish like a pie plate, stir together the breadcrumbs, Parmesan cheese, and salt.
        
                3. Working one at a time, dip each mozzarella stick into the egg wash, let the excess drip off, then roll in the breadcrumbs. Repeat the process for each mozzarella stick for a double coating of bread crumbs by dipping again in the egg wash and breadcrumbs before transferring to a sheet pan. Continue until all of the cheese is coated and the breadcrumbs have been used up.
        
                4. Transfer the mozzarella sticks to the freezer and freeze for at least 1 hour.
        
                5. Fill a large skillet at least 1"-2" deep with vegetable oil, or use a deep fryer if you have one. Heat the oil to between 350 and 365 degrees F over medium-high heat. The temperature will drop when the frozen mozzarella sticks are added, so use a thermometer to monitor the oil temp and keep it in range.
        
                6. Working in batches, fry 5-6 mozzarella sticks at a time for 1-2 minutes, carefully turning with tongs halfway through, until crispy and golden brown on the outside. Remove the fried mozzarella sticks to a plate lined with a paper towel to soak up any excess oil.
        
                7. Continue to fry the remaining mozzarella sticks, then serve hot with marinara sauce for dipping.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 29 - main dish American clam chowder
        """
        
        Clam Chowder
        ----------------------------------------------
        
            -- Ingredients --
                * 4 slices bacon, diced
                * 2 tablespoons unsalted butter
                * 2 cloves garlic, minced
                * 1 onion, diced
                * 1/2 teaspoon dried thyme
                * 3 tablespoons all-purpose flour
                * 1 cup milk
                * 1 cup vegetable stock
                * 2 (6.5-ounce) cans chopped clams, juices reserved
                * 1 bay leaf
                * 2 russet potatoes, peeled and diced
                * 1 cup half and half*
                * Kosher salt and freshly ground black pepper, to taste
                * 2 tablespoons chopped fresh parsley leaves

        
            -- Directions --
                1. Heat a large stockpot or Dutch oven over medium high heat. Add bacon and cook until brown and crispy, about 6-8 minutes. Transfer to a paper towel-lined plate, reserving 1 tablespoon excess fat in the stockpot.
        
                2. Melt butter in the stockpot. Add garlic and onion, and cook, stirring frequently, until onions have become translucent, about 2-3 minutes.
        
                3. Stir in thyme until fragrant, about 1 minute.
        
                4. Whisk in flour until lightly browned, about 1 minute. Gradually whisk in milk, vegetable stock, clam juice and bay leaf, and cook, whisking constantly, until slightly thickened, about 1-2 minutes. Stir in potatoes.
        
                5. Bring to a boil; reduce heat and simmer until potatoes are tender, about 12-15 minutes.
        
                6. Stir in half and half and clams until heated through, about 1-2 minutes; season with salt and pepper, to taste. If the soup is too thick, add more half and half as needed until desired consistency is reached.
        
                7. Serve immediately, garnished with bacon and parsley, if desired.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 30 - main dish American BBQ brisket
        """
        
        Texas BBQ Brisket
        ----------------------------------------------
        
            -- Ingredients --
                * One 9-pound whole beef brisket
                * Sea salt and freshly ground black pepper
                * 4 tablespoons unsalted butter
                * 3 large garlic cloves, smashed
                * 1 teaspoon ground coriander
                * 1 cup barbecue sauce
                * 1 cup low-sodium beef broth

        
            -- Directions --
                1. Generously season the brisket all over with salt and pepper. Place the brisket on a large rimmed baking sheet, cover with plastic wrap and refrigerate overnight.
        
                2. Light a charcoal fire in a starter chimney. Add the lit coals to the firebox of a smoker and heat the smoker to 275°. Place oak or other hardwood chips, chunks or logs around the coals so that the wood smolders but does not flare. Set the brisket on the grill, fat side down. Cover and smoke for 2 hours. Monitor the smoker throughout the smoking process and add more lit coals and/or wood as needed to maintain the temperature and smoke level.
        
                3. Meanwhile, in a small saucepan, combine the butter with the garlic and coriander and cook over moderate heat until fragrant, about 2 minutes. Add the barbecue sauce and beef broth and simmer the mop for 5 minutes. Season with salt and pepper.
        
                4. After 2 hours, brush the brisket all over with the mop. Turn the brisket fat side up. Continue to cook, mopping every 30 minutes, until an instant-read thermometer in the thickest part registers 165°, about 6 1/2 hours longer.
        
                5. Transfer the brisket to a large sheet of heavy-duty foil. Brush the remaining mop and garlic all over the brisket and wrap it in the foil. Put the wrapped brisket in a large, disposable aluminum roasting pan. Set the pan in the smoker and cook the brisket until it reaches 185°, about 1 hour longer.
        
                6. Slice the brisket thinly across the grain and serve it with its cooking juices.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 31 - main dish American pot roast
        """
        
        Pot Roast
        ----------------------------------------------
        
            -- Ingredients --
                * Salt and freshly ground black pepper
                * One 3- to 5-pound chuck roast
                * 2 or 3 tablespoons olive oil
                * 2 whole onions, peeled and halved
                * 6 to 8 whole carrots, unpeeled, cut into 2-inch pieces
                * 1 cup red wine, optional
                * 3 cups beef broth
                * 2 or 3 sprigs fresh rosemary
                * 2 or 3 sprigs fresh thyme

        
            -- Directions --
                1. Preheat the oven to 275 degrees F.
        
                2. Generously salt and pepper the chuck roast.
        
                3. Heat the olive oil in a large pot or Dutch oven over medium-high heat. Add the halved onions to the pot, browning them on both sides. Remove the onions to a plate.
        
                4. Throw the carrots into the same very hot pot and toss them around a bit until lightly browned, about a minute or so. Reserve the carrots with the onions.
        
                5. If needed, add a bit more olive oil to the very hot pot. Place the meat in the pot and sear it for about a minute on all sides until it is nice and brown all over. Remove the roast to a plate.
        
                6. With the burner still on high, use either red wine or beef broth (about 1 cup) to deglaze the pot, scraping the bottom with a whisk. Place the roast back into the pot and add enough beef stock to cover the meat halfway.
        
                7. Add in the onions and the carrots, along with the fresh herbs.
            
                8. Put the lid on, then roast for 3 hours for a 3-pound roast. For a 4 to 5-pound roast, plan on 4 hours. The roast is ready when it's fall-apart tender.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 32 - dessert American apple pie
        """
        
        Apple Pie
        ----------------------------------------------
        
            -- Ingredients --
                * 2 (9") pie crusts
                * 7 large Granny Smith apples (Peeled, cored and sliced into ½ inch slices)
                * ½ cup granulated sugar
                * ½ cup light brown sugar (loosely packed)
                * 2 tablespoons all-purpose flour
                * 1 teaspoon ground cinnamon
                * ⅛ teaspoon ground nutmeg
                * 1 lemon (zest and juice)
                * 1 large egg (lightly beaten in a small bowl for egg wash)
                * 2 tablespoons sanding sugar (optional)


        
            -- Directions --
                1. Start by preparing this flaky pie crust recipe which makes 2 (9") pie crusts, one for the bottom and one for the top of the pie. Or use a store-bought pie crust and follow package directions.
        
                2. Place oven rack in the center position and Preheat the oven to 400°F.
        
                3. In a large bowl, combine the sliced apples, granulated sugar, light brown sugar, flour, cinnamon, nutmeg, and the zest and juice of one lemon; toss to coat evenly.
        
                4. Remove the pie crust dough from the fridge and let rest at room temperature for 5-10 minutes. On a lightly floured surface, roll one disc into a 12" circle that is ⅛" thick. Carefully lay the crust into the bottom of a deep dish pie plate.
        
                5. Spoon the apple filling over the bottom crust and discard juices at the bottom of the bowl. Roll out the second disc of pie crust until it is ⅛" thick and lay it over the apple filling.
        
                6. Use a sharp knife to trim the dough along the outside edge of the pie plate. Lift the edges where the two pie crust meet, gently press to seal and fold them under. Rotate the pie plate and repeat this process until edges are neatly tucked under themselves. Cut 4 slits in the top of the dough to allow steam to vent. Place the pie on a baking sheet.
        
                7. Brush the surface of the pie crust with the egg wash and sprinkle with sanding sugar. Cover the edges with a pie shield or a strip of foil to keep them from over browning during the first 25 minutes.
            
                8. Bake at 400°F for 25 minutes. Carefully remove the pie shield, turn the oven down to 375° and continue to bake for an additional 30-35 minutes or until the top is golden brown and the juices are bubbly. Cool at room temperature for at least 3 hours.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 33 - dessert American carrot cake
        """
        
        Carrot Cake
        ----------------------------------------------
        
            -- Ingredients --
                * Salt and freshly ground black pepper
                * One 3- to 5-pound chuck roast
                * 2 or 3 tablespoons olive oil
                * 2 whole onions, peeled and halved
                * 6 to 8 whole carrots, unpeeled, cut into 2-inch pieces
                * 1 cup red wine, optional
                * 3 cups beef broth
                * 2 or 3 sprigs fresh rosemary
                * 2 or 3 sprigs fresh thyme

        
            -- Directions --
                1. Preheat the oven to 275 degrees F.
        
                2. Generously salt and pepper the chuck roast.
        
                3. Heat the olive oil in a large pot or Dutch oven over medium-high heat. Add the halved onions to the pot, browning them on both sides. Remove the onions to a plate.
        
                4. Throw the carrots into the same very hot pot and toss them around a bit until lightly browned, about a minute or so. Reserve the carrots with the onions.
        
                5. If needed, add a bit more olive oil to the very hot pot. Place the meat in the pot and sear it for about a minute on all sides until it is nice and brown all over. Remove the roast to a plate.
        
                6. With the burner still on high, use either red wine or beef broth (about 1 cup) to deglaze the pot, scraping the bottom with a whisk. Place the roast back into the pot and add enough beef stock to cover the meat halfway.
        
                7. Add in the onions and the carrots, along with the fresh herbs.
            
                8. Put the lid on, then roast for 3 hours for a 3-pound roast. For a 4 to 5-pound roast, plan on 4 hours. The roast is ready when it's fall-apart tender.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 34 - dessert American banana pudding
        """
        
        Banana Pudding
        ----------------------------------------------
        
            -- Ingredients --
                * Salt and freshly ground black pepper
                * One 3- to 5-pound chuck roast
                * 2 or 3 tablespoons olive oil
                * 2 whole onions, peeled and halved
                * 6 to 8 whole carrots, unpeeled, cut into 2-inch pieces
                * 1 cup red wine, optional
                * 3 cups beef broth
                * 2 or 3 sprigs fresh rosemary
                * 2 or 3 sprigs fresh thyme

        
            -- Directions --
                1. Preheat the oven to 275 degrees F.
        
                2. Generously salt and pepper the chuck roast.
        
                3. Heat the olive oil in a large pot or Dutch oven over medium-high heat. Add the halved onions to the pot, browning them on both sides. Remove the onions to a plate.
        
                4. Throw the carrots into the same very hot pot and toss them around a bit until lightly browned, about a minute or so. Reserve the carrots with the onions.
        
                5. If needed, add a bit more olive oil to the very hot pot. Place the meat in the pot and sear it for about a minute on all sides until it is nice and brown all over. Remove the roast to a plate.
        
                6. With the burner still on high, use either red wine or beef broth (about 1 cup) to deglaze the pot, scraping the bottom with a whisk. Place the roast back into the pot and add enough beef stock to cover the meat halfway.
        
                7. Add in the onions and the carrots, along with the fresh herbs.
            
                8. Put the lid on, then roast for 3 hours for a 3-pound roast. For a 4 to 5-pound roast, plan on 4 hours. The roast is ready when it's fall-apart tender.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 35 - drink American bloody mary
        """
        
        Bloody Mary
        ----------------------------------------------
        
            
            Bloody Mary is made with a  combination of vodka (1.5oz), tomato juice (3oz), lemon juice (0.3oz), Worcestershire sauce (3 dashes), tabasco, celery salt, and pepper.

        
            Serve in a tall highball glass with a celery stalk (used for stirring the cocktail).


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 36 - drink American Old-fashioned
        """
        
        Old-fashioned
        ----------------------------------------------
        
            Bourbon or whiskey (1.5oz), fine sugar or a sugar cube, Angostura bitters (2 dashes), Maraschino cherries, orange slices, and a splash of club soda or water (2 dashes).
        
        
            Muddle the bitters, sugar, cherries, an orange slice, and soda or water in an old-fashioned glass.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 37 - drink American pina colada
        """
        
        Pina Colada
        ----------------------------------------------
        
            Mixture of rum (1oz), pineapple juice (3oz), coconut milk, and coconut cream (1oz), often shaken or blended with ice, served in a chilled glass, then garnished with a piece of pineapple or a cherry on top.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 38 - appetizer Mexican guac dip
        """
        
        Guacamole Dip
        ----------------------------------------------
        
            -- Ingredients --
                * 3 avocados, ripe
                * 1/2 small onion, finely diced
                * 2 Roma tomatoes, diced
                * 3 tablespoons finely chopped fresh cilantro
                * 1 jalapeno pepper, seeds removed and finely diced
                * 2 garlic cloves, minced
                * 1 lime, juiced
                * 1/2 teaspoon sea salt


        
            -- Directions --
                1. Slice the avocados in half, remove the pit, and scoop into a mixing bowl.
        
                2. Mash the avocado with a fork and make it as chunky or smooth as you'd like.
        
                3. Add the remaining ingredients and stir together. Give it a taste test and add a pinch more salt or lime juice if needed.
        
                4. Serve the guacamole with tortilla chips.


        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 39 - appetizer Mexican salsa dip
        """
        
        Salsa Dip
        ----------------------------------------------
        
            -- Ingredients --
                * Ripe tomatoes – cored and quartered, no peeling necessary
                * Red onion – peeled and quartered
                * Garlic cloves – peeled
                * Jalapeños – stemmed and seeded
                * Cilantro
                * Fresh lime juice
                * Ground cumin
                * Sugar – optional. Sometimes the tomatoes need a little boost to balance the acidity.
                * Salt
                * Canned crushed San Marzano tomatoes
                * Diced green chiles



        
            -- Directions --
                1. Prepare the veggies and add them to your food processor along with lime juice and seasonings. Chop to a fine grade.
        
                2. Next, add the canned crushed San Marzano tomatoes and green chiles and puree again until almost smooth. The canned tomatoes provide a rustic essence and sweetness that accentuates the fresh produce, while the canned green chiles deliver a smoky quality that fresh peppers are lacking.
        
                3. Add more cumin and salt to taste, and refrigerate until chilled and ready to enjoy.

        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 40 - appetizer Mexican cochinita pibil
        """
        
        Cochinita Pibil
        ----------------------------------------------
        
            -- Ingredients --
                -Pibil-
                * 2 tablespoons annatto seeds
                * 1 tablespoon cumin seeds
                * 2 ½ teaspoons coriander seeds
                * 2 ½ teaspoons Mexican Oregano can sub. Italian oregano
                * 1 ½ teaspoons black peppercorns
                * 6 whole cloves
                * 1 (2 inch) piece cinnamon stick
                * 1 shallot, minced
                * 6 garlic cloves, minced
                * ¾ cup lime juice (6-8 limes)
                * ½ cup orange juice (2 medium oranges)
                * 2 tablespoon extra virgin olive oil
                * 3 pound boneless pork shoulder, trimmed and cut into large chunks
                * ½ teaspoon salt
                * 1 pound banana leaves, thawed (unless fresh)

            -Pickled Red Onions-
                * ¾ cup white vinegar
                * 3 tablespoons sugar
                * 2 teaspoons yellow mustard seeds
                * ¼ teaspoon salt
                * 1 bay leaf, lightly crushed
                * 4 allspice berries
                * 3 whole cloves
                * 1 large red onion, peeled, and thinly sliced

            -Cilantro Crema-
                * ½ bunch cilantro
                * ⅔ cup Mexican crema can use sour cream plus 1 1/2 tablespoons milk


        
        
            -- Directions --
                1. Place the first 7 ingredients into a spice grinder or mortar and finely grind. Place spice mixture into a mixing bowl and add shallots, garlic, lime juice, orange juice, and oil. Whisk together.
        
                2. Season pork shoulder with salt and place into a roasting pan or large baking dish lined with layers of banana leaves. Pour marinade over pork shoulder and generously rub all over meat.
        
                3. Cover pork with remaining banana leaves and top with a damp towel. Place in the refrigerator and allow pork to marinate for 12 hours (overnight).
                
                4. Preheat the oven to 325°F.
        
                5. Remove the towel from the pork and allow the pork to sit out at room temperature for 1 hour. Add 1 cup water to the baking dish and place in the oven. Slow roast for about 3 hours or until tender enough to pull apart with two forks.
        
                6. Remove from the oven and allow the pibil to sit for 15 minutes. Uncover pork from banana leaves and shred. Adjust seasonings if needed and serve with beans and rice or in tacos.
        
                7. Pickled onions: Place all ingredients, except onions, into a small saucepan and simmer until sugar dissolves. Place onions into a mixing bowl and top with pickling mixture. Cover and allow the mixture to sit for at least 1 hour. Serve.
        
                8. Cilantro crema: Place ingredients into a food processor and process until smooth. Serve.
        
                9. To assemble: Top grilled tortillas with pibil and finish with pickled onions, crema, radishes and cilantro. Serve.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 41 - entree Mexican mole poblano
        """
        
        Mole Poblano
        ----------------------------------------------
        
            -- Ingredients --
                * 12 dried ancho chiles
                * 12 dried guajillo chiles
                * 6 dried pasilla chiles
                * 4 tablespoons sesame seeds
                * 1 teaspoon aniseed
                * 1 teaspoon black peppercorns
                * 1/2 teaspoon whole cloves
                * 1 teaspoon dried thyme
                * 1/2 teaspoon dried marjoram
                * 3 dried bay leaves, crumbled
                * 1 (1 1/2-inch) stick cinnamon, broken into pieces
                * 2 cups canola oil
                * 7 1/4 cups chicken stock
                * 1/2 cup skin-on almonds
                * 1/2 cup raw shelled peanuts
                * 1/3 cup hulled pumpkin seeds (pepitas)
                * 1/3 cup raisins
                * 2 slices white bread
                * 2 stale corn tortillas
                * 1 medium onion, thinly sliced (about 1 cup)
                * 10 medium cloves garlic, minced (about 10 teaspoons)
                * 2 large tomatillos, husked, rinsed, and quartered
                * 1 large tomato, quartered
                * 1 cup ﬁnely chopped Mexican chocolate
                * 4 tablespoons sugar, plus more to taste
                * Kosher salt, to taste



        
            -- Directions --
                1. Stem chiles and shake seeds into a small bowl. Tear chiles into large pieces; set aside. Place 4 tablespoons of reserved chile seeds and sesame seeds in a small cast iron skillet set over medium heat. Toast seeds, stirring occasionally, until lightly brown, about 2 minutes. Transfer seeds to a spice grinder. Add aniseed, peppercorns, and cloves to now empty skillet. Toast until fragrant, about 1 minute; transfer to spice grinder with seeds. Add thyme, marjoram, bay leaves, and cinnamon to spice grinder. Grind all seeds and spices into a fine powder. Transfer to a large bowl; set aside.
        
                2. Heat oil in a medium skillet over medium-high heat to 350°F (177°C). Working in batches, fry chiles until slightly darkened, about 20 seconds per batch; transfer chiles to paper towel-lined plate as each batch is finished. Remove skillet from heat and reserve. Transfer chiles to a large bowl and add boiling water to cover. Let steep for 30 minutes. Strain chiles, reserving soaking liquid.
        
                3. Working in 3 batches, place 1/3 of the chiles, 1/3 cup soaking liquid, and 1/4 cup chicken stock into blender and purée until as smooth as possible. Set a fine-mesh strainer over a large bowl and strain chile mixture, using a rubber spatula to push through as much chile mixture as possible. Discard solids and set chile purée aside.
        
                4. Return skillet with oil to 350°F over medium-high heat. One at a time, fry almonds, peanuts, pumpkin seeds, and raisins until toasted, about 1 minute for almonds, 45 seconds for peanuts, 20 seconds for pumpkin seeds, and 15 seconds for raisins. Transfer each batch to a paper towel-lined plate as it is done. Transfer almonds, peanuts, pumpkin seeds, and raisins to bowl with spice mixture.
        
                5. Fry bread until golden brown, 1 to 2 minutes per side; transfer to paper towel lined-plate. Fry tortillas until golden brown, about 1 minute per side; transfer to paper towel-lined plate. Remove skillet from heat. Break bread and tortillas into small pieces and transfer to bowl with spice mixture.
        
                6. Set fine-mesh strainer over small bowl and strain oil from skillet. Place 2 tablespoons of strained oil to now empty skillet. Heat over medium-high heat until shimmering. Add in onions and cook until browned, about 10 minutes, stirring occasionally. Stir in garlic and cook until fragrant, about 1 minute. Transfer onions and garlic to bowl with spice mixture, leaving as much oil in pan as possible.
        
                7. Return skillet to medium-high heat. When oil is shimmering, add in tomatillos and tomatoes. Cook until softened, about 10 minutes, stirring occasionally. Transfer tomatillos and tomato to bowl with spice mixture. Add 2 1/2 cups of chicken stock to bowl with spice mixture.
        
                8. Working in two batches, purée spice mixture in blender until as smooth as possible. Set a fine-mesh strainer over a large bowl and strain spice mixture, using a rubber spatula to push through as much spice mixture as possible. Discard solids and set spice mixture aside.
        
                9. In a large Dutch oven or pot, heat 3 tablespoons of reserved strained oil over medium-high heat until shimmering. Add in chile purée and cook, stirring constantly, until mixture has thickened to consistency of tomato paste, about 10 minutes. Stir in spice mixture, bring to a boil, then reduce heat to low and simmer, stirring frequently, for 30 minutes. Stir in 4 cups chicken stock and chocolate. Simmer, partially covered, for 1 hour, stirring occasionally. Stir in sugar and season mole with salt and additional sugar to taste. Remove from heat, use immediately or transfer to airtight container and store in refrigerator for up to a month.

        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 42 - entree Mexican posole
        """
        
        Posole
        ----------------------------------------------
        
            -- Ingredients --
                * 4 ounces dried guajillo or ancho chiles, or a combination of both
                * Salt
                * 1 large (108 ounce, 6 lb 12 oz, 3 kg) can white hominy, drained and rinsed
                * 3 pounds pork shoulder (preferably with bone), cut into 1 to 1 1/2 inch cubes (can also use pork shanks), make sure to use a cut well marbled with fat
                * 8 cloves garlic, 4 cloves roughly chopped, and 4 whole cloves
                * 3 bay leaves
                * 1 teaspoon ground cumin
                * 2 tablespoons dry oregano (Mexican oregano if available)



        
            -- Directions --
                1. Fill a large 10-12 quart stockpot with 5 quarts of water. Set on heat to bring to a boil while you proceed with the next steps.
        
                2. Remove and discard the stems, seeds, and large veins from the chili pods. Heat a cast iron pan on medium high and heat the chili pods for a couple minutes, until they begin to soften. Do not let them burn.
        
                3. While the chilies are heating, bring a medium pot with 3 cups of water to a simmer and remove from heat. Once the chiles have softened, add the chiles to the pot hot water and cover.
        
                    Let the chiles soak in the hot water for 15 to 20 minutes.
        
                4. Heat a tablespoon or two of olive oil (enough to coat the bottom of the pan) in a large sauté pan on medium high heat. Pat the pork pieces dry with paper towels. Sprinkle them generously with salt.
                    
                    Working in batches, taking care not to crowd the pan or stir the meat much, brown the meat on all sides.
        
                    Right at the end of browning the meat, add 4 cloves of roughly chopped garlic to the pan with the meat, let cook with the meat for about a minute.
        
                5. Once the meat has browned, transfer it to the large stockpot of boiling water. Scrape up any browned bits at the bottom of the pan, and any garlic, and add those to the pot as well. Add the rinsed hominy.
        
                    Add bay leaves, cumin, and oregano. When you put the oregano in, smoosh together with your hands so that the oregano breaks up more as it goes in. Add a tablespoons of salt. Bring to a simmer, reduce the heat and cook for 15 minutes.
        
                6. Prepare the red sauce: by puréeing in a blender the chilies, 2 1/2 cups or so of their soaking liquid, a teaspoon of salt, and 4 cloves of garlic. (To prevent the blender from creating too much pressure, it's probably best to start with the chiles and garlic and only a cup of the liquid in the blender, and then adding the rest of the liquid.)
        
                    Strain the red sauce through a sieve, discarding the tough bits of the sauce.
        
                7. Add another couple teaspoons of salt. Return to a simmer, lower the heat to just high enough to maintain a simmer, partially covered.
        
                8. Skim away excess fat. Taste for seasoning and add more salt to taste (you will likely need more than you expect, perhaps a tablespoon or more.)

        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 43 - entree Mexican tamales
        """
        
        Tamales
        ----------------------------------------------
        
            -- Ingredients --
                * 7-8 pounds pork butt or pork shoulder
                * 2 1/2 cups water
                * 1 tablespoon sea salt
                * 6 1/2 cups Red Chile Sauce
                * 1 Batch Tamale Masa
                * Corn husks, ojas




            -- Directions --
        
                -Shredded Pork-
                1. Place pork, water, and salt in a slow cooker and cook for 6 to 8 hours. After meat is cooked, remove from the slow cooker and let cool to room temperature. Shred pork and remove fat while shredding, reserving fat. (Usually, after pork is cooked and shredded, you will be left with about 3 pounds of meat.)
        
                2. In a blender combine the cooled broth from the cooked pork and the leftover fat pieces. Blend and reserve for using when making tamale masa and filling. Broth can be kept, tightly covered, for 1 week in the refrigerator. The broth also freezes well and will keep for 4 to 6 months.
                
                -Filling-
                1. Heat the 6 tablespoons broth in a large skillet. Add flour and whisk for at least 4 to 5 minutes.
        
                2. Add red chile sauce and salt, stir, and cook for 10 minutes. The chile sauce will be very thick at this time.
        
                3. Add the 3 pounds shredded pork and stir so all the pork is well coated with the red chile sauce. Simmer for at least 10 minutes. Let mixture cool before filling tamales.
        
                -Prepare Ojas (Corn Husks)-
                1. Soak corn husks in water for an hour before using, rinse well with running water to take off any dust or corn husk fibers. To keep corn husks pliable and easy to work with, keep in water while filling tamales. Place a handful of wet corn husks in a colander to drain before using.
        
                -Spread Masa-
                1. Place the wide end of the husk on the palm of your hand, narrow end is at the top. Starting at the middle of the husk spread 2 tablespoons of the masa with the back of a spoon in a rectangle or oval shape, using a downward motion towards the wide-bottom edge. Do not spread the masa to the ends; leave about a 2-inch border on the left and right sides of the husk.
        
                -Fill Corn Husks-
                1. Spoon 1 1/2 tablespoons of your chosen filling down the center of the masa. Fold both sides to the center; finish off by bringing the pointed end of the husk toward the filled end. Make sure it’s a snug closure so the tamal will not open during steaming. Secure by tying a thin strip of corn husk around the tamal. This will keep the tamal from unwrapping during the steaming process, especially if the husk is too thick and will not stay folded.
        
                -Steam Tamales-
                1. Use a deep pot or tamale steamer to steam tamales. If using a tamale steamer fill with water up to the fill line. Set the tamale rack over the water. Place tamales upright, with fold against the sides of the other tamales to keep them from unfolding. Cover pot with a tightly fitting lid. Set heat on high and bring to a boil, about 15 minutes. Lower heat and simmer for 2 1/2 to 3 hours. Keep lid on tightly. To test if done, put one tamal on a plate and take off the corn husk. If it comes off without sticking to the tamal they are done.

        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 44 - dessert Mexican Bunuelos
        """
        
        Bunuelos
        ----------------------------------------------
        
            -- Ingredients --
                * 3 cups all-purpose flour
                * 1 teaspoon baking powder
                * 1 teaspoon salt
                * 1 teaspoon ground cinnamon
                * ¾ cup milk
                * ¼ cup butter
                * 1 teaspoon vanilla
                * 2 beaten eggs
                * Canola or vegetable oil for frying



        
            -- Directions --
                1. In a mixing bowl combine flour, baking powder, salt, and cinnamon.
        
                2. In a saucepan heat milk, butter, and vanilla and bring to a boil. Set aside to cool.
        
                3. In a separate bowl, mix the eggs, then add the beaten eggs to the room temperature milk mixture and whisk quickly.
        
                4. Add the liquid mixture to dry ingredients and mix well.
        
                5. Knead dough on lightly floured surface 2 to 3 minutes until smooth.
        
                6. After you knead the dough, divide into 20 dough balls. With a rolling pin, roll out thin tortillas.
        
                7. Lay out all the thin tortilla flats on a tablecloth and let them dry. Turn them over once to ensure drying on both sides. This helps remove most of the moisture before frying.
        
                8. Heat one-inch of oil in a skillet wide enough for the tortillas to fry flat. Deep-fry tortillas until golden brown, turning once. Remove from pan; stand vertically in a bowl lined with paper towels and drain excess oil.
        
                9. While warm, sprinkle fried tortillas on both sides with sugar-cinnamon mixture.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 45 - dessert Mexican capirotada
        """
        
        Capirotada
        ----------------------------------------------
        
            -- Ingredients --
                * 4 bolillo rolls or French rolls
                * 4 1/2 cups water
                * 12 ounces piloncillo or 1½ cups packed dark brown sugar
                * 4 cinnamon sticks
                * 6 whole cloves
                * 3 cups shredded cheese, Longhorn Cheddar, Colby, or cheese of your choice
                * 1 cup raisins
                * 4 tablespoons butter or spray butter



        
            -- Directions --
                1. Preheat oven to 350 degrees F.
        
                2. Cut rolls in ½ inch slices and butter both sides, layer on a baking sheet and bake for 3 minutes on each side, until lightly toasted and dry. Remove and cool.
        
                3. Combine water, piloncillo, cinnamon sticks, and cloves in a large saucepan. Bring to a boil; reduce heat, creating a syrup. Simmer syrup uncovered for 20 minutes. Remove from heat and let steep, covered for 2 hours. Pour through a strainer and discard cinnamon sticks and cloves. Set syrup aside.
        
                4. Spray 8 x 10 ½” baking dish with non-stick spray, layer ingredients in the following order: a third of the toasted bread, third of the raisins, third of the cheese, and 1 1/2 cups syrup evenly over cheese. Wait 15 minutes and layer another third of the bread, raisins, cheese, and 1 1/2 cups syrup evenly over cheese. Let soak for another 15 minutes, and again top with the remaining bread, raisins, cheese, and syrup evenly over bread. Before baking let set for another 15 minutes.
        
                5. Cover the dish with aluminum foil that has been sprayed with nonstick spray and bake 40 minutes, uncover and bake until cheese is golden brown about 10 to 15 minutes more. Serve warm.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 46 - dessert Mexican pan de muerto
        """
        
        Pan de Muerto
        ----------------------------------------------
        
            -- Ingredients --
                * 1 envelope active dry yeast
                * 1/4 cup water, about 125°
                * 1/2 cup milk
                * 2 whole eggs, beaten
                * 1/4 cup of butter, melted
                * 3 cups all-purpose flour
                * 1/4 cup sugar
                * 1/2 teaspoon  salt
                * 1 teaspoon fennel seeds or anise seed
                * 1 egg white
                * 1 tablespoon  water
                * 1 tablespoon colored sugar or granulated sugar



        
            -- Directions --
                1. Combine yeast with warm water in medium bowl and set aside until foamy, about 5 minutes. Stir in milk, whole eggs and melted butter; set aside.
        
                2. Sift flour, sugar and salt in large mixing bowl. Stir in fennel seeds. Make a well in the center of flour mixture. Stir yeast mixture into flour mixture with a wooden spoon until dough forms. Add a little more flour if the dough is too wet or a little more milk if it is too dry.
        
                3. Knead on lightly floured surface until dough is smooth but slightly sticky, about 10 minutes. Transfer dough to large, lightly greased bowl. Cover and let rise in a warm place until doubled, about 1 hour.
        
                4. Preheat oven to 350°. Spray baking sheet with no-stick spray. Knead dough on lightly floured surface 3 minutes. Cut about 1/5 of the dough off; reserve. Shape remaining dough into a round loaf on prepared baking sheet. Roll reserved dough into a thick rope, then cut into 5 portions. Roll one portion into a ball and arrange it on top of the round loaf. Roll the remaining 4 balls into ropes with knobby ends resembling ''bones''. Arrange ''bones'' around loaf. Cover loosely and let it rise in a warm place until doubled about 30 minutes.
        
                5. Beat egg white with water, then brush loaf with egg wash. Sprinkle with sugar. Bake 35 minutes or until the top is lightly golden brown. Remove to wire rack and cool.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 47 - drinks Mexican arroz con leche
        """
        
        Arroz con Leche
        ----------------------------------------------
        
            -- Ingredients --
                * 4 cups water
                * 2 cinnamon sticks
                * 3 to 5 whole cloves
                * ¼ teaspoon salt
                * ¾ cup long-grain rice
                * ¾ cup evaporated milk
                * ½ cup sweetened condensed milk
                * 1 cup dark raisins
                * 1 tablespoon ground cinnamon, for sprinkling when serving



        
            -- Directions --
                1. Over high heat, bring the water to a boil with the cinnamon sticks, cloves, and salt.
        
                2. Remove from the heat and cover. Steep for about 45 minutes to 1 hour.
        
                3. Remove cinnamon sticks and cloves and discard. Add rice and over medium heat boil for 20 minutes.
        
                4. Add the evaporated milk, condensed milk, and raisins and continue to cook over low heat for about 5 minutes. Stir gently but be careful not to stir too much so rice doesn’t get mushy.
        
                5. Ladle into bowls and sprinkle with cinnamon.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 48 - drinks Mexican agua de horchata
        """
        
        Agua de Horchata
        ----------------------------------------------
        
            -- Ingredients --
                * 1 cup uncooked long-grain white rice, ground
                * 6 cups hot water
                * 2 cloves, whole
                * 1 cinnamon stick
                * 1/2 teaspoon vanilla extract
                * 2 cups simple syrup



        
            -- Directions --
                1. In a medium saucepan combine sugar and water. Over low heat allow the sugar to melt, stirring until sugar has dissolved. Allow to cool.
        
                2. In a food processor or coffee grinder, pulverize the rice so it is the consistency of ground coffee.
        
                3. In a large saucepan over high heat, bring the water to a boil. Remove from heat and let cool; add rice, cinnamon stick, and cloves. Cover and let soak for eight hours or overnight at room temperature.
        
                4. After soaking, break the cinnamon stick in half, and place the water, rice, broken cinnamon stick, and cloves in a blender. Puree for 2-3 minutes.
        
                5. Pour the liquid through a fine strainer lined with a double layer of cheesecloth, into a pitcher. Squeeze the excess liquid and discard the solids.
        
                6. Stir in the vanilla and 2 cups of the thin simple syrup.
        
                7. Cover and refrigerate until you’re ready to serve. Stir before pouring and serve over ice.
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
    StoryPage( // 49 - drinks Mexican agua de jamaica
        """
        
        Agua de Jamaica
        ----------------------------------------------
        
            -- Ingredients --
                * 2 cups dried hibiscus flowers
                * 3/4 cup granulated sugar, more if desired
                * 6 cups water
                * Ice
                * Mint leaves, optional



        
            -- Directions --
                1. Rinse and drain the dried hibiscus flowers in a large colander.
        
                2. Bring water to a boil in a pot. Add the flowers and cover tightly with a lid. Remove from the heat and steep for 1 hour or until cool.
        
                3. Strain hibiscus water into a pitcher and discard flowers. Add sugar and stir. Refrigerate until time to serve.
        
                4. Taste tea, and add more sugar or dilute with water to your liking.
        
                5. Ladle into a tall glass filled with ice and garnish with fresh mint leaves or lime slices (optional).
        """,
        choices: [
//            Choice(text: "It’s in the shape of a rainbow.", destination: 15),
//            Choice(text: "It has multicolored candies on the outside.", destination: 10),
//            Choice(text: "It has marshmallow clouds.", destination: 11),
        ]
    ),
])
